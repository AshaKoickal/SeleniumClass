package constant;

public class Constant {
	public static final String lp_verifyLoginWithValidCredentials=":Heading text is as expected";
	public static final String lp_verifyLoginWithInValidCredentials="Heading text is not as expected";
	public static final String lp_expectedHeadingForValidCredentials="7rmart supermarket";
	public static final String mc_MandatoryFieldsNeedtobeFilledMessage="Mandatory fields need to be filled before updating Contact details";
	public static final String mc_ContactDetailsUpdatedSuccessfullyMessage="Contact details updated successfully";
	public static final String mn_newsAddedSuccessfullyMessage="News added successfully";
	public static final String cg_categoryAddedSuccessfulMessage="Category Added Successfully";
	public static final String cg_expectedcategoryAddedMessage="�\n" + "Alert!\n" + "Category Created Successfully";
	public static final String sc_expectedSubCategoryAddedMessage="�\n" + "Alert!\n" + "Sub Category Created Successfully";
	public static final String mc_validSearch="Searched item exist in table";
	public static final String mc_entryNotExists ="Searched item does not exist in table";
}
